var divDodatno=document.getElementById("dodatno");
    
var textField1=document.createElement("input");
var textField2=document.createElement("input");
    
textField1.type="text";
textField1.placeholder="Set semestar";
textField1.id="semestar";
   
textField2.type="text";
textField2.placeholder="Set smer";
textField2.id="smer";

var flag=0;
var kurcina = 1;

function addFields(){  
    clearFields();
    if(flag==0){
        divDodatno.appendChild(textField1);
        divDodatno.appendChild(textField2);
        flag=1;
    }
}

function clearFields(){
    if(flag==1){
        divDodatno.removeChild(textField1);
        divDodatno.removeChild(textField2);
        flag=0;
    }
}



function registracija(){
    
    var url;
    var permission=document.getElementById("permission").value;
    
    if(permission==1){
        url="/registerStudent?username="+document.getElementById("username").value
                        +"&password="+document.getElementById("password").value
                        +"&firstName="+document.getElementById("firstName").value
                        +"&lastName="+document.getElementById("lastName").value
                        +"&semestar="+document.getElementById("semestar").value
                        +"&smer="+document.getElementById("smer").value;
    }  
    else if(permission==2){
        url="/registerProfessor?username="+document.getElementById("username").value
                        +"&password="+document.getElementById("password").value
                        +"&firstName="+document.getElementById("firstName").value
                        +"&lastName="+document.getElementById("lastName").value;
    }
    else{
        url="/registerAdministrator?username="+document.getElementById("username").value
                        +"&password="+document.getElementById("password").value
                        +"&firstName="+document.getElementById("firstName").value
                        +"&lastName="+document.getElementById("lastName").value;
    }
            
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() { 
        if (xmlHttp.readyState === 4 && xmlHttp.status === 200)  console.log("Sve je kako treba");
    }
    xmlHttp.open("GET", url, false); // true for asynchronous 
    xmlHttp.send();
    
    console.log(xmlHttp.readyState + " / " + xmlHttp.status);
    
    window.location="/login";
}

function loginDugme()
{
    url="/loginUser?username="+document.getElementById("username").value
                  +"&password="+document.getElementById("password").value;
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.onreadystatechange = function() { 
        
        console.log(xmlHttp.readyState + " / " + xmlHttp.status);
        
        if (xmlHttp.readyState === 4 && xmlHttp.status === 200)     console.log("Sve je kako treba");
        }
        xmlHttp.open("GET", url, true); // true for asynchronous 
         
        xmlHttp.send();
       
        window.location="/";
}